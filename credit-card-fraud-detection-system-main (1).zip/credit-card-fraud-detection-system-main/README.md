# 💳 Credit Card Fraud Detection System

## 🚀 Overview

This project is an **end-to-end machine learning system** designed to detect fraudulent credit card transactions in near real-time. It tackles one of the most critical challenges in banking and fintech: identifying rare fraud events in highly imbalanced datasets.

The system includes:

* Data preprocessing & feature scaling
* Imbalanced data handling using SMOTE
* Model training using XGBoost
* Automated evaluation & visualization
* HTML report generation
* FastAPI-based prediction API

---

## 🎯 Problem Statement

Credit card fraud detection is a **binary classification problem** where:

* `0` → Legitimate transaction
* `1` → Fraudulent transaction

### Key Challenges:

* Extreme class imbalance (~0.17% fraud cases)
* Need for **high recall** (catch fraud)
* Maintain **precision** (avoid false alarms)

---

## 🧠 Solution Approach

### 🔄 Pipeline

```
Raw Data → Preprocessing → SMOTE → Model Training → Evaluation → Prediction → Visualization → API
```

### ⚙️ Techniques Used

* Data Scaling (StandardScaler)
* SMOTE (Synthetic Minority Oversampling)
* XGBoost Classifier
* Evaluation Metrics:

  * Precision
  * Recall
  * F1-score
  * Confusion Matrix
  * ROC Curve
  * Precision-Recall Curve

---

## 🏗️ Project Structure

```
Credit-Card-Fraud-Detection/
│
├── data/                 # Dataset (creditcard.csv)
├── src/                  # Core ML pipeline
│   ├── preprocess.py
│   ├── train.py
│   ├── evaluate.py
│   ├── visualize.py
│   └── utils.py
│
├── api/                  # FastAPI app
│   └── app.py
│
├── models/               # Saved model
├── images/               # Generated graphs
├── outputs/              # Predictions
├── reports/              # HTML report
│
├── main.py               # Main pipeline runner
├── requirements.txt
└── README.md
```

---

## 📊 Results & Outputs

### ✔ Generated Visualizations

* Confusion Matrix
* Class Distribution
* Precision-Recall Curve
* ROC Curve

### ✔ Files Generated

```
images/
models/model.pkl
outputs/predictions.csv
reports/report.html
```

---

## 📸 Sample Outputs

### Confusion Matrix

![Confusion Matrix](images/confusion_matrix.png)

### ROC Curve

![ROC Curve](images/roc_curve.png)

### Precision-Recall Curve

![PR Curve](images/pr_curve.png)

---

## ⚡ Installation & Setup

### 1. Clone Repository

```bash
git clone https://github.com/your-username/credit-card-fraud-detection-system.git
cd credit-card-fraud-detection-system
```

### 2. Create Virtual Environment

```bash
python -m venv venv
venv\Scripts\activate   # Windows
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

---

## ▶️ Run the Project

```bash
python main.py
```

### Output:

* Model trained
* Graphs saved in `/images`
* Report generated in `/reports`

---

## 🌐 Run API (Optional)

```bash
uvicorn api.app:app --reload
```

Open:

```
http://127.0.0.1:8000/docs
```

---

## 🧪 Dataset

* Source: Public credit card transactions dataset
* Total Records: 284,807
* Fraud Cases: 492

---

## 💡 Key Highlights

✔ Handles **highly imbalanced data**
✔ Uses **industry-level model (XGBoost)**
✔ Generates **automated visual reports**
✔ Deployable via **FastAPI**
✔ Clean modular architecture

---

## 📈 Future Improvements

* SHAP Explainability (feature importance)
* Real-time streaming (Kafka)
* Threshold optimization (cost-based)
* Dashboard (Next.js)

---

## 🎤 Interview Talking Points

* “I handled class imbalance using SMOTE”
* “Optimized fraud detection using XGBoost”
* “Focused on recall to minimize fraud loss”
* “Built an end-to-end ML pipeline with API deployment”

---

## 👨‍💻 Author

**Garv Vashisht**

---

## ⭐ If you found this useful, give it a star!
